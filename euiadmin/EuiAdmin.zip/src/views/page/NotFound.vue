<template>
    <div id="back">
        <h1 id="title" class="animate__animated animate__bounce animate__infinite infinite">4<span style="color:#409EFF">0</span>4</h1>
        <div style="margin:auto;width:600px;height:5px;background-color:#67C23A"></div>
        <p >页面不存在，请您及时联系管理员</p>
    </div>
</template>
<style scoped>
h1 {
  color: #606266;
}
p {
  color: #606266;
  padding-top: 20px;
}
#title{
   padding-top: 20vh;
   font-size: 800%;
}
#back{
    min-height: 100vh;
    text-align: center;
}
</style>