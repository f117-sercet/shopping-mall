<template>
    <div id="back">
        <i id="title" class="el-icon-warning-outline animate__animated animate__pulse animate__infinite infinite"/>
        <div style="margin:auto;width:600px;height:5px;background-color:#E6A23C"></div>
        <p >系统错误，请您及时联系管理员</p>
    </div>
</template>
<style scoped>
p {
  color: #606266;
  padding-top: 20px;
}
#title{
   padding-top: 20vh;
   font-size: 1000%;
   color: #F56C6C;
}
#back{
    min-height: 100vh;
    text-align: center;
}
</style>